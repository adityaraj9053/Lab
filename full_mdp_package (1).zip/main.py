# main.py - Complete MDP Demo (Value Iteration, Policy Iteration, Q-Learning)
# (Full implementation exactly as used to generate results)

import numpy as np
import matplotlib.pyplot as plt
import random
from collections import defaultdict

class GridWorldMDP:
    def __init__(self, n_rows=4, n_cols=4, terminal_states=None, slip_prob=0.1, default_reward=-0.04, gamma=0.99):
        self.n_rows = n_rows
        self.n_cols = n_cols
        self.n_states = n_rows * n_cols
        self.terminal = set(terminal_states or [])
        self.slip = slip_prob
        self.default_reward = default_reward
        self.gamma = gamma
        self.actions = ['U','R','D','L']
        self.action_vectors = {'U':(-1,0),'R':(0,1),'D':(1,0),'L':(0,-1)}

    def s2rc(self, s):
        return divmod(s, self.n_cols)

    def rc2s(self, r, c):
        return r*self.n_cols + c

    def in_bounds(self, r, c):
        return 0 <= r < self.n_rows and 0 <= c < self.n_cols

    def step_result(self, s, a):
        if s in self.terminal:
            return [(1.0, s, 0.0, True)]
        r, c = self.s2rc(s)
        results = []
        intended = a
        perp = ['L','R'] if a in ['U','D'] else ['U','D']
        probs = [(1-self.slip, intended), (self.slip/2, perp[0]), (self.slip/2, perp[1])]
        for p, act in probs:
            dr, dc = self.action_vectors[act]
            nr, nc = r + dr, c + dc
            if not self.in_bounds(nr,nc):
                ns = s
            else:
                ns = self.rc2s(nr, nc)
            reward = self.default_reward
            done = ns in self.terminal
            results.append((p, ns, reward, done))

        combined = {}
        for p,ns,re,d in results:
            if ns not in combined:
                combined[ns] = [0.0, re, d]
            combined[ns][0] += p
        return [(prob, ns, combined[ns][1], combined[ns][2]) for ns,(prob,_,_) in combined.items()]

def value_iteration(mdp, theta=1e-6):
    V = np.zeros(mdp.n_states)
    for t in mdp.terminal:
        V[t] = 0.0
    while True:
        delta = 0.0
        for s in range(mdp.n_states):
            if s in mdp.terminal:
                continue
            old = V[s]
            action_vals = []
            for a in mdp.actions:
                val = 0.0
                for p,ns,r,done in mdp.step_result(s,a):
                    val += p*(r + mdp.gamma*V[ns])
                action_vals.append(val)
            V[s] = max(action_vals)
            delta = max(delta, abs(old - V[s]))
        if delta < theta:
            break

    policy = {}
    for s in range(mdp.n_states):
        if s in mdp.terminal:
            policy[s] = None
            continue
        best_a = None
        best_val = -1e9
        for a in mdp.actions:
            val = 0.0
            for p,ns,r,done in mdp.step_result(s,a):
                val += p*(r + mdp.gamma*V[ns])
            if val > best_val:
                best_val = val
                best_a = a
        policy[s] = best_a
    return V, policy

def policy_iteration(mdp):
    policy = {s: random.choice(mdp.actions) for s in range(mdp.n_states)}
    for t in mdp.terminal:
        policy[t] = None

    while True:
        V = np.zeros(mdp.n_states)
        while True:
            delta = 0.0
            for s in range(mdp.n_states):
                if s in mdp.terminal:
                    continue
                old = V[s]
                a = policy[s]
                val = 0.0
                for p,ns,r,done in mdp.step_result(s,a):
                    val += p*(r + mdp.gamma*V[ns])
                V[s] = val
                delta = max(delta, abs(old - val))
            if delta < 1e-6:
                break

        stable = True
        for s in range(mdp.n_states):
            if s in mdp.terminal:
                continue
            old_a = policy[s]
            best_a = None
            best_val = -1e9
            for a in mdp.actions:
                val = 0.0
                for p,ns,r,done in mdp.step_result(s,a):
                    val += p*(r + mdp.gamma*V[ns])
                if val > best_val:
                    best_val = val
                    best_a = a
            policy[s] = best_a
            if best_a != old_a:
                stable = False

        if stable:
            return V, policy

def q_learning(mdp, episodes=2000, alpha=0.1, epsilon=0.1):
    Q = np.zeros((mdp.n_states, len(mdp.actions)))
    action_idx = {a:i for i,a in enumerate(mdp.actions)}

    for ep in range(episodes):
        s = random.choice([x for x in range(mdp.n_states) if x not in mdp.terminal])
        while True:
            a = mdp.actions[random.randrange(4)] if random.random() < epsilon else mdp.actions[np.argmax(Q[s])]
            a_i = action_idx[a]
            transitions = mdp.step_result(s,a)
            probs = [t[0] for t in transitions]
            idx = np.random.choice(len(transitions), p=probs)
            _, ns, r, done = transitions[idx]
            Q[s,a_i] += alpha*(r + mdp.gamma*np.max(Q[ns]) - Q[s,a_i])
            s = ns
            if done:
                break

    policy = {}
    for s in range(mdp.n_states):
        if s in mdp.terminal:
            policy[s] = None
        else:
            policy[s] = mdp.actions[np.argmax(Q[s])]
    return Q, policy

if __name__ == "__main__":
    mdp = GridWorldMDP(4,4,[0,15])
    V_vi, pi_vi = value_iteration(mdp)
    V_pi, pi_pi = policy_iteration(mdp)
    Q, pi_q = q_learning(mdp)

    print("Value Iteration Policy:", pi_vi)
    print("Policy Iteration Policy:", pi_pi)
    print("Q-Learning Policy:", pi_q)
